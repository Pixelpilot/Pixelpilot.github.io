// Kontext herstellen
var canv = document.getElementById('myCanvas');
var context = canv.getContext('2d');

function draw() {

	drawSomePrimitives();

	drawRectangleExamples ();
}

function drawSomePrimitives(){

	// Eigenschaften der nachfolgenden Form definieren
	context.fillStyle = "red";

	// Kreis
	context.beginPath();
	context.arc (480, 100, 80, 0, 2 * Math.PI );
	context.fill();
	context.closePath();

	// Rechteck
	context.beginPath();
	context.rect (400,200,160, 80);
	context.fillStyle = "yellow";
	context.fill();
	context.closePath();

	// Polygon
	context.beginPath();
	context.moveTo (480, 300);
	context.lineTo ( 560, 380);
	context.lineTo ( 400, 380);
	context.lineTo ( 480, 300);
	context.fillStyle = "blue";
	context.fill();
	context.closePath();
	
}

function drawRectangleExamples (){

	// Eigenschaften der nachfolgenden Form definieren
	context.lineWidth = 2;
	context.strokeStyle = "green";
	context.fillStyle = "red";

	// Transformationen: 
	// Achtung - Reihenfolge ist wichtig

	// Aktuelle Transformationen speichern
	context.save();

	// Skalieren
	context.scale(.9, .9);
	context.strokeStyle = "red";
	context.strokeRect(100, 50, 100, 100);

	// Rotieren
	context.rotate(30 * Math.PI / 180);
	context.strokeStyle = "green";
	context.strokeRect(100, 50, 100, 100);

	// Translieren
	context.translate(150, -50);
	context.strokeStyle = "blue";
	context.strokeRect(100, 50, 100, 100);

	// Gespeicherte Transformationen wieder herstellen
	context.restore();
}