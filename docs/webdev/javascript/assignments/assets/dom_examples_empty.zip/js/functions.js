// globale Variablen
var imageUrls = new Array("img/crossfit.webp","img/lift.jpeg","img/swim.jpeg","img/tennis.webp", "img/yoga.webp");

var curImg = 0;
var slideId = -1;


// Initialisieren und Eventhandler dran hängen
window.onload = function (){
	
	// Elemente anzeigen
	document.getElementById ("bt_show_all").onclick = showAllDivs;

	// Todo: Weitere Klick-Events erstellen
	
}

// Alle Divs anzeigen
function showAllDivs (){

	// Referenz auf alle Divs herstellen
	var divs = document.getElementsByTagName("div");
	
	// Anzahl ausgeben
	console.log ("Anzahl der div-Elemente auf der Seite: " + divs.length );

	// Alle Divs anzeigen
	for ( var i = 0; i < divs.length ; i ++ )	{
		
		// Auslesen eines Attributes
		var id = divs[i].getAttribute ("id");
		console.log ("div - id: " + id );
		
		// Alternativ auch mit .-Notation
		// console.log ("div - id: " + divs[i].id );
	}
}