// define images
var gImages = new Array ("./pics/img_01.jpg", "./pics/img_02.jpg", "./pics/img_03.jpg", "./pics/img_04.jpg", "./pics/img_05.jpg", "./pics/img_06.jpg");
var gThumbs = new Array ("./pics/thumb_01.jpg", "./pics/thumb_02.jpg", "./pics/thumb_03.jpg", "./pics/thumb_04.jpg", "./pics/thumb_05.jpg", "./pics/thumb_06.jpg");
