function showCanvas () {

	// Referenz zum Canvas-Objekt herstellen
	lCanvas = document.getElementById("my2dCanvas");
	lContext = lCanvas.getContext("2d");

	// Rechteck zeichnen
	lContext.fillStyle = "#ff0000";
	lContext.fillRect ( 10, 10, 50, 50 );
}

/*
Cheatsheet
http://www.nihilogic.dk/labs/canvas_sheet/HTML5_Canvas_Cheat_Sheet.pdf
*/
