<?php
	include "functions.php";

	// TODO: Sessionvariblen und Cookie löschen
?>