<?php
	include "functions.php";

	// TODO: Loginformular erstellen und Session-Varible setzen wenn Login-Daten korrekt
?>
<h2>Login</h2>

<p>Um die Applikation nutzen zu können, ist ein Login notwendig.</p>

